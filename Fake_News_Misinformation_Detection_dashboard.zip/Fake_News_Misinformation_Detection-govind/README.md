Fake News & Misinformation Detection 

## Interactive dashboard

A Streamlit dashboard is included in `dashboard.py`. It presents saved model metrics, prediction distributions, a prediction explorer, dataset/signal summaries, and an article-analyzer interface.

### Run locally

```bash
pip install -r requirements.txt
pip install -r requirements-dashboard.txt
streamlit run dashboard.py
```

Open the local URL printed by Streamlit (usually `http://localhost:8501`). Run the command from the project root so the dashboard can find `results/` and `data/`.

**Important:** the archive includes evaluation results but does not include a saved fitted model artifact. The Article analyzer will explicitly report that live inference is not available until you save a trained scikit-learn pipeline at `models/baseline/pipeline.joblib` (or one of the supported candidate paths). The dashboard does not fabricate predictions. The DistilBERT results report 100% test metrics; audit for leakage, duplicate content, and split issues before interpreting that as generalization.

from pathlib import Path
import json
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
DATA = ROOT / 'data'

st.set_page_config(page_title='SignalCheck | Misinformation Intelligence', page_icon='◈', layout='wide', initial_sidebar_state='expanded')

# --- Visual system ---
st.markdown('''
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap');
:root { --bg:#0b1020; --panel:#121a2d; --line:rgba(148,163,184,.15); --muted:#91a0b9; --text:#eef3ff; --cyan:#54d6d0; --violet:#a78bfa; }
html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
.stApp { background: radial-gradient(ellipse at 75% -10%, rgba(70,91,160,.20), transparent 42%), #0b1020; color:var(--text); }
.block-container { padding-top:1.4rem; max-width:1500px; }
h1,h2,h3 { font-family:'Space Grotesk',sans-serif !important; letter-spacing:-.035em; color:#f4f7ff; }
[data-testid="stSidebar"] { background:#0e1527; border-right:1px solid var(--line); }
[data-testid="stSidebar"] * { color:#e6ecfb; }
[data-testid="stMetric"] { background:linear-gradient(145deg,rgba(25,37,62,.95),rgba(17,26,44,.92)); border:1px solid var(--line); padding:17px 19px; border-radius:16px; }
[data-testid="stMetricLabel"] { color:#9baac4 !important; font-size:.82rem; }
[data-testid="stMetricValue"] { color:#f5f7ff !important; font-family:'Space Grotesk',sans-serif; }
[data-testid="stMetricDelta"] { font-size:.75rem; }
.panel { background:linear-gradient(145deg,rgba(22,32,54,.94),rgba(15,23,40,.95)); border:1px solid var(--line); border-radius:18px; padding:20px 22px; margin-bottom:14px; }
.eyebrow { text-transform:uppercase; letter-spacing:.16em; color:#8fa1c0; font-size:.70rem; font-weight:700; }
.hero-title { font-family:'Space Grotesk',sans-serif; font-size:2.35rem; line-height:1.08; font-weight:700; letter-spacing:-.055em; margin:.35rem 0 .65rem; }
.subtle { color:#9aa9c1; font-size:.93rem; }
.pill { display:inline-block; border:1px solid rgba(84,214,208,.3); background:rgba(84,214,208,.09); color:#75e5df; border-radius:999px; padding:5px 10px; font-size:.72rem; font-weight:700; }
.small-note { color:#9aa9c1; font-size:.82rem; }
div.stButton > button { border-radius:10px; border:1px solid rgba(84,214,208,.35); background:linear-gradient(90deg,#40c8c4,#68ded3); color:#07151d; font-weight:700; }
div.stButton > button:hover { border-color:#9bf7ef; color:#06131a; }
.stTabs [data-baseweb="tab-list"] { gap:8px; }
.stTabs [data-baseweb="tab"] { background:#121a2d; border-radius:10px; padding:8px 14px; }
hr { border-color:var(--line); }
</style>
''', unsafe_allow_html=True)

COLORS = {'Real':'#54d6d0','Fake':'#fb7185','Baseline':'#a78bfa','DistilBERT':'#54d6d0','Rule-based':'#fbbf24'}
PLOT = dict(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#c7d2e5', margin=dict(l=12,r=12,t=36,b=12), legend=dict(bgcolor='rgba(0,0,0,0)'))

def read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}

def read_csv(path):
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()

def pct(v): return f'{v*100:.2f}%'

baseline_metrics = read_json(RESULTS/'baseline'/'metrics_v0_raw.json')
transformer_metrics = read_json(RESULTS/'transformer'/'metrics_distilbert.json')
comparison = read_csv(RESULTS/'comparison'/'comparison_table.csv')
pred = read_csv(RESULTS/'transformer'/'predictions_distilbert.csv')
if pred.empty: pred = read_csv(RESULTS/'baseline'/'predictions_v0_raw.csv')
terms_fake = read_csv(RESULTS/'baseline'/'top_fake_terms_v0_raw.csv')
terms_real = read_csv(RESULTS/'baseline'/'top_real_terms_v0_raw.csv')
training = read_csv(RESULTS/'transformer'/'training_log.csv')
splits = read_csv(DATA/'splits'/'split.csv')

with st.sidebar:
    st.markdown('<div style="font-family:Space Grotesk;font-size:1.5rem;font-weight:700;letter-spacing:-.05em">◈ SignalCheck</div>', unsafe_allow_html=True)
    st.markdown('<div class="small-note">Misinformation intelligence platform</div>', unsafe_allow_html=True)
    st.divider()
    page = st.radio('WORKSPACE', ['Overview','Article analyzer','Model performance','Prediction explorer','Dataset & signals'], label_visibility='visible')
    st.divider()
    st.markdown('<div class="eyebrow">SYSTEM STATUS</div>', unsafe_allow_html=True)
    st.markdown('<span class="pill">RESULTS LOADED</span>', unsafe_allow_html=True)
    st.caption('Dashboard reads the project’s saved evaluation artifacts. Live inference requires model weights.')
    st.markdown('---')
    st.caption('Fake News & Misinformation Detection · v1.0')

st.markdown('<div class="eyebrow">TRUST & SAFETY ANALYTICS / PROJECT CONSOLE</div>', unsafe_allow_html=True)

if page == 'Overview':
    st.markdown('<div class="hero-title">Understand the signal.<br>Challenge the claim.</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtle">A single workspace for model quality, prediction confidence, dataset coverage, and misinformation review.</div>', unsafe_allow_html=True)
    st.write('')
    test = transformer_metrics.get('test', {}) or baseline_metrics.get('test', {})
    n_articles = len(pred)
    fake_share = float((pred['y_pred']==1).mean()) if not pred.empty and 'y_pred' in pred else 0
    c1,c2,c3,c4 = st.columns(4)
    c1.metric('Test accuracy', pct(float(test.get('accuracy',0))), 'Saved evaluation')
    c2.metric('Fake-class F1', pct(float(test.get('f1_fake',0))), 'Precision + recall')
    c3.metric('Evaluated predictions', f'{n_articles:,}', 'Loaded from CSV')
    c4.metric('Predicted fake share', pct(fake_share), 'Prediction sample')
    st.write('')
    left,right = st.columns([1.35,1])
    with left:
        st.markdown('<div class="panel"><div class="eyebrow">MODEL BENCHMARK</div><h3>Performance at a glance</h3>', unsafe_allow_html=True)
        if not comparison.empty and 'model' in comparison.columns:
            metric_cols = [x for x in ['accuracy','precision_fake','recall_fake','f1_fake'] if x in comparison.columns]
            long = comparison.melt(id_vars='model',value_vars=metric_cols,var_name='Metric',value_name='Score')
            fig=px.bar(long,x='Metric',y='Score',color='model',barmode='group',text=long['Score'].map(lambda x:f'{x:.3f}'),color_discrete_sequence=['#a78bfa','#54d6d0','#fbbf24'])
            fig.update_layout(**PLOT, height=320, yaxis=dict(range=[0,1.08],gridcolor='rgba(148,163,184,.12)',title='Score'),xaxis=dict(title=''))
            fig.update_traces(textposition='outside',cliponaxis=False)
            st.plotly_chart(fig,use_container_width=True)
        else: st.info('Comparison results are not available yet.')
        st.markdown('</div>', unsafe_allow_html=True)
    with right:
        st.markdown('<div class="panel"><div class="eyebrow">PREDICTION MIX</div><h3>Model output distribution</h3>', unsafe_allow_html=True)
        if not pred.empty and 'y_pred' in pred:
            counts=pred['y_pred'].map({0:'Real',1:'Fake'}).fillna(pred['y_pred'].astype(str)).value_counts().rename_axis('Class').reset_index(name='Articles')
            fig=px.pie(counts,names='Class',values='Articles',hole=.72,color='Class',color_discrete_map=COLORS)
            fig.update_layout(**PLOT,height=300,showlegend=True)
            fig.update_traces(textinfo='percent+label',textfont_size=12)
            st.plotly_chart(fig,use_container_width=True)
        else: st.info('Prediction file not found.')
        st.markdown('</div>', unsafe_allow_html=True)
    st.markdown('<div class="panel"><div class="eyebrow">REVIEW PRIORITY</div><h3>What to validate next</h3><p class="subtle">A perfect score is a reason to investigate, not a guarantee of real-world reliability. Check for label leakage, duplicate articles, source artifacts, and train/test overlap before relying on these results.</p></div>', unsafe_allow_html=True)
    a,b,c=st.columns(3)
    with a: st.markdown('**01 · Data integrity**'); st.caption('Audit split boundaries, duplicate text, and label construction.')
    with b: st.markdown('**02 · Error analysis**'); st.caption('Inspect false positives and false negatives by source and topic.')
    with c: st.markdown('**03 · Deployment readiness**'); st.caption('Persist the model, calibrate confidence, and test on out-of-domain news.')

elif page == 'Article analyzer':
    st.markdown('<div class="hero-title">Article analyzer</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtle">Submit a claim for review. This interface only runs genuine inference when trained model artifacts are present.</div>', unsafe_allow_html=True)
    st.write('')
    article = st.text_area('Article or claim text', height=220, placeholder='Paste the headline and article body here…')
    source = st.text_input('Publisher / source (optional)', placeholder='e.g. publisher name or domain')
    col1,col2=st.columns([1,2])
    with col1: analyze=st.button('Analyze article',use_container_width=True)
    with col2: st.caption('Treat the output as a triage signal, not a factual verdict. Verify claims against independent primary sources.')
    model_candidates = [ROOT/'models'/'baseline'/'model.joblib',ROOT/'models'/'baseline'/'pipeline.joblib',ROOT/'models'/'baseline'/'tfidf_lr.joblib']
    model_path=next((p for p in model_candidates if p.exists()),None)
    if analyze:
        if len(article.strip()) < 30:
            st.warning('Please enter a little more text (at least 30 characters) for a meaningful review.')
        elif model_path:
            try:
                import joblib
                model=joblib.load(model_path)
                label=model.predict([article])[0]
                probs=model.predict_proba([article])[0] if hasattr(model,'predict_proba') else None
                fake_prob=float(probs[1]) if probs is not None and len(probs)>1 else None
                c1,c2=st.columns(2)
                c1.metric('Model classification','Potentially fake' if int(label)==1 else 'Potentially real')
                c2.metric('Fake probability',pct(fake_prob) if fake_prob is not None else 'Not available')
                st.info('Model output is a probabilistic classification, not independent verification of the article’s claims.')
            except Exception as e: st.error(f'Could not load or run the saved model: {e}')
        else:
            st.warning('Live prediction is not connected yet: this project archive contains evaluation CSVs and metrics, but no saved model weights/vectorizer were found in models/baseline/.')
            st.markdown('**To enable live inference:** run the baseline training script, save the fitted vectorizer and classifier as one scikit-learn Pipeline, then load that artifact here. The current dashboard will not invent a fake/real score.')
            st.code("# In train_baseline.py, after fitting the pipeline\nimport joblib\njoblib.dump(pipeline, ROOT / 'models' / 'baseline' / 'pipeline.joblib')",language='python')
    if source.strip(): st.caption(f'Source entered for analyst context: {source}. Publisher identity alone does not establish credibility.')

elif page == 'Model performance':
    st.markdown('<div class="hero-title">Model performance</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtle">Compare validation and test metrics, inspect the confusion matrix, and review training behavior.</div>', unsafe_allow_html=True)
    models = {'TF-IDF + Logistic Regression':baseline_metrics,'DistilBERT':transformer_metrics}
    metric_rows=[]
    for name,obj in models.items():
        for split_name in ['val','test']:
            d=obj.get(split_name,{})
            if d: metric_rows.append({'Model':name,'Split':split_name.title(),**{k:d.get(k,np.nan) for k in ['accuracy','precision_fake','recall_fake','f1_fake']}})
    if metric_rows:
        df=pd.DataFrame(metric_rows)
        metric=st.selectbox('Metric to compare',['accuracy','precision_fake','recall_fake','f1_fake'],format_func=lambda x:x.replace('_',' ').title())
        fig=px.bar(df,x='Model',y=metric,color='Split',barmode='group',text=df[metric].map(lambda x:f'{x:.4f}'),color_discrete_sequence=['#a78bfa','#54d6d0'])
        fig.update_layout(**PLOT,height=350,yaxis=dict(range=[0,1.08],gridcolor='rgba(148,163,184,.12)',title=metric.replace('_',' ').title()),xaxis=dict(title=''))
        fig.update_traces(textposition='outside',cliponaxis=False)
        st.plotly_chart(fig,use_container_width=True)
        st.dataframe(df.style.format({k:'{:.4f}' for k in ['accuracy','precision_fake','recall_fake','f1_fake']}),use_container_width=True,hide_index=True)
    st.markdown('### Confusion matrix')
    cm=transformer_metrics.get('test',{}).get('confusion_matrix')
    if cm:
        fig=px.imshow(np.array(cm),text_auto=True,x=['Predicted real','Predicted fake'],y=['Actual real','Actual fake'],color_continuous_scale=['#111a2d','#54d6d0'],aspect='auto')
        fig.update_layout(**PLOT,height=330,coloraxis_showscale=False)
        st.plotly_chart(fig,use_container_width=True)
    if not training.empty and {'epoch','loss'}.issubset(training.columns):
        st.markdown('### Training diagnostics')
        tr=training.copy()
        tr['epoch']=pd.to_numeric(tr['epoch'],errors='coerce'); tr['loss']=pd.to_numeric(tr['loss'],errors='coerce')
        fig=px.line(tr.dropna(subset=['epoch','loss']),x='epoch',y='loss',markers=True)
        fig.update_traces(line_color='#a78bfa')
        fig.update_layout(**PLOT,height=280,xaxis_title='Epoch',yaxis_title='Training loss')
        st.plotly_chart(fig,use_container_width=True)
    st.warning('DistilBERT reports 100% on the saved validation and test metrics. Confirm the split protocol and inspect for leakage or duplicates before treating this as credible generalization.')

elif page == 'Prediction explorer':
    st.markdown('<div class="hero-title">Prediction explorer</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtle">Filter saved predictions and inspect confidence and error cases.</div>', unsafe_allow_html=True)
    if pred.empty:
        st.info('No prediction artifact found in results/.')
    else:
        df=pred.copy()
        if 'y_true' in df: df['Actual']=df['y_true'].map({0:'Real',1:'Fake'})
        if 'y_pred' in df: df['Predicted']=df['y_pred'].map({0:'Real',1:'Fake'})
        if 'prob_fake' in df: df['Fake probability']=pd.to_numeric(df['prob_fake'],errors='coerce')
        if 'split' in df:
            split_opts=['All']+sorted(df['split'].dropna().astype(str).unique().tolist())
            selected=st.selectbox('Dataset split',split_opts)
            if selected!='All': df=df[df['split'].astype(str)==selected]
        col1,col2,col3=st.columns(3)
        if 'Predicted' in df:
            label_filter=col1.selectbox('Predicted class',['All','Fake','Real'])
            if label_filter!='All': df=df[df['Predicted']==label_filter]
        if 'Fake probability' in df:
            min_conf=col2.slider('Minimum fake probability',0.0,1.0,0.0,0.05)
            df=df[df['Fake probability']>=min_conf]
        if 'Actual' in df and 'Predicted' in df:
            errors=df[df['Actual']!=df['Predicted']]
            show_errors=col3.checkbox('Errors only',value=False)
            if show_errors: df=errors
            st.metric('Rows matching filters',f'{len(df):,}',f'{len(errors):,} errors in filtered base')
        display=[c for c in ['row_id','split','Actual','Predicted','Fake probability','prob_fake','y_true','y_pred'] if c in df.columns]
        st.dataframe(df[display].head(2000),use_container_width=True,hide_index=True)
        if 'Fake probability' in df:
            fig=px.histogram(df,x='Fake probability',nbins=30,color='Predicted' if 'Predicted' in df else None,color_discrete_map=COLORS)
            fig.update_layout(**PLOT,height=300,xaxis_title='Predicted fake probability',yaxis_title='Articles')
            st.plotly_chart(fig,use_container_width=True)
        st.download_button('Download filtered CSV',df.to_csv(index=False).encode('utf-8'),file_name='filtered_predictions.csv',mime='text/csv')

elif page == 'Dataset & signals':
    st.markdown('<div class="hero-title">Dataset & signals</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtle">Explore available split metadata and baseline text signals.</div>', unsafe_allow_html=True)
    a,b,c=st.columns(3)
    a.metric('Split rows',f'{len(splits):,}')
    if not splits.empty and 'split' in splits: b.metric('Split groups',splits['split'].nunique())
    if not splits.empty and 'split' in splits:
        counts=splits['split'].value_counts().rename_axis('Split').reset_index(name='Rows')
        fig=px.bar(counts,x='Split',y='Rows',color='Split',color_discrete_sequence=['#54d6d0','#a78bfa','#fbbf24'])
        fig.update_layout(**PLOT,height=300,showlegend=False)
        st.plotly_chart(fig,use_container_width=True)
        st.dataframe(counts,use_container_width=True,hide_index=True)
    l,r=st.columns(2)
    with l:
        st.markdown('### Top baseline fake-associated terms')
        if not terms_fake.empty:
            st.dataframe(terms_fake,use_container_width=True,hide_index=True)
            num_col=next((c for c in terms_fake.columns if pd.api.types.is_numeric_dtype(terms_fake[c])),None)
            term_col=next((c for c in terms_fake.columns if c!=num_col),None)
            if num_col and term_col:
                fig=px.bar(terms_fake.head(12).sort_values(num_col),x=num_col,y=term_col,orientation='h')
                fig.update_layout(**PLOT,height=350,xaxis_title='Weight',yaxis_title='')
                st.plotly_chart(fig,use_container_width=True)
        else: st.caption('No term artifact available.')
    with r:
        st.markdown('### Top baseline real-associated terms')
        if not terms_real.empty:
            st.dataframe(terms_real,use_container_width=True,hide_index=True)
            num_col=next((c for c in terms_real.columns if pd.api.types.is_numeric_dtype(terms_real[c])),None)
            term_col=next((c for c in terms_real.columns if c!=num_col),None)
            if num_col and term_col:
                fig=px.bar(terms_real.head(12).sort_values(num_col),x=num_col,y=term_col,orientation='h')
                fig.update_layout(**PLOT,height=350,xaxis_title='Weight',yaxis_title='')
                st.plotly_chart(fig,use_container_width=True)
        else: st.caption('No term artifact available.')
    st.markdown('<div class="panel"><div class="eyebrow">INTERPRETATION NOTE</div><p class="subtle">Term associations reflect patterns learned from the dataset, not proof that an article is true or false. Evaluate source credibility with provenance, independent corroboration, author history, and transparent evidence—not lexical cues alone.</p></div>',unsafe_allow_html=True)

st.markdown('<hr/>',unsafe_allow_html=True)
st.markdown('<div class="small-note">SignalCheck · Research dashboard · Saved metrics are dataset-specific and should not be interpreted as a guarantee of factual truth.</div>',unsafe_allow_html=True)
